package com.example.posttest3_annisaadhiasalsabila_1915016020

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
